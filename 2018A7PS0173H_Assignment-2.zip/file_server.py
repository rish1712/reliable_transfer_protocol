#Rohan Sinha 2018A7PS0417H
#Rishab Nahar 2018A7PS0173H
#Vatsal Gupta 2018A7PS0198H
#Samkit Jain 2017B2A71723H

import os
from rudp import RUDPServer
import struct
CHUNK = 1024 * 15

class Util:

    def __init__(self, sock):
        self.sock = sock

    def recvall(self, length):
        data = b''
        rem = length
        while rem > 0:
            new_data = self.sock.recv(rem)
            if not new_data:
                raise Exception('peer closed')
            data += new_data
            rem = length - len(data)
        return data

    def recv(self):
        l = self.sock.recv(4)
        if not l:
            return None
        assert (len(l) == 4)
        l, = struct.unpack('!I', l)
        data = self.recvall(l)
        return data

    def send(self, data):
        if type(data) == str:
            data = data.encode('ascii')
        l = len(data)
        l = struct.pack('!I', l)
        databytes = l
        databytes += data
        self.sock.send(databytes)


def handle_client(sock, addr):
    print_addr=addr
    print("Server conection made with ", print_addr)
    u = Util(sock)
    recv_var=u.recv()
    fname = recv_var.decode('ascii')
    #fname = fname
    if os.path.isfile(fname):
        u.send('OK')
    else:
        print('No file in this directory. ')
        u.send('File not found!')
        print('Closed connection...', addr)
        sock.close()
        return
    idx = 0
    f = open(fname, 'rb')
    while True:
        data = f.read(CHUNK)
        if not data:
            print('Finished transfer...', addr)
            sock.close()
            f.close()
            return
        u.send(data)
        idx = idx+1
        print(idx, 'buff size:', sock.buff, end='\r')
    print('Something went wrong...', addr)

def server(addr):
    sock = RUDPServer()
    sock.bind(addr)
    sock.listen()
    print("Server Listening")
    while True:
        sc, addr = sock.accept()
        handle_client(sc, addr)

if __name__ == "__main__":
    server(("127.0.0.1", 8012))