#Rohan Sinha 2018A7PS0417H
#Rishab Nahar 2018A7PS0173H
#Vatsal Gupta 2018A7PS0198H
#Samkit Jain 2017B2A71723H
from rudp import RUDPClient
import time
import struct

class Util:
    def __init__(self, sock):
        self.sock = sock

    def recvall(self, length):
        data = b''
        rem = length
        while rem > 0:
            utill_socket=self.sock
            new_data = utill_socket.recv(rem)
            if not new_data:
                raise Exception('ERROR in the protocol')
            data += new_data
            rem = length
            rem-=len(data)
        return data

    def recv(self):
        utill_socket=self.sock
        l = utill_socket.recv(4)
        if not l:
            return None
        assert (len(l) == 4)
        l, = struct.unpack('!I', l)
        data = self.recvall(l)
        return data

    def send(self, data):
        if type(data) == str:
            data = data.encode('ascii')
        l = len(data)
        l = struct.pack('!I', l)
        databytes = l
        databytes += data
        utill_socket = self.sock
        utill_socket.send(databytes)


def client(addr, filename):
    sock = RUDPClient()
    sock.connect(addr)
    print('Connection with server established...')
    u = Util(sock)
    u.send(filename)
    recieve=u.recv()
    status = recieve.decode('ascii')
    if status != "OK":
        print(status)
        sock.close()
        return
    idx = 0
    f = open("new_"+filename, 'wb')
    start_time = time.time()
    print('Asking for file...')
    
    while True:  
        start = time.time()
        data = u.recv()
        idx += 1
        end = time.time()
        print('Block:', idx, end - start, end='\r')
        if not data:
            print('File has been transferred sucessfully!')
            end_time = time.time()
            time_taken = end_time - start_time
            print('The time taken to complete file transfer is ', time_taken, 's')
            break
        f.write(data)
    f.close()
    sock.close()


if __name__ == "__main__":

    print("Enter a file name to download from the server")
    file_name = input()
    print("File name :{}".format(file_name))
    client(("127.0.0.1", 8012), file_name)
