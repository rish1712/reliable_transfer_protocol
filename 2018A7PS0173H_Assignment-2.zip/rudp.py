#Rohan Sinha 2018A7PS0417H
#Rishab Nahar 2018A7PS0173H
#Vatsal Gupta 2018A7PS0198H
#Samkit Jain 2017B2A71723H

import socket
import time
import datetime
from threading import Lock
import threading


MAX_BYTES = 90000  # 65535 should be less than receiver buffer size
MAX_PCKT_SIZE = 1460
POLL_INTERVAL = 0.1  # 10 polls / sec
HEADER_SIZE = 9
TIMEOUT = 0.2  # seconds
RWND = 10  # Retransmission window size (maximum no of packets to be retransmitted after timeout)
#DEBUG_CNTR=0



class debug_func:
    def __init__(self):
        self.debug = 0
        pass

    def debug_func(self):
        self.debug += 1

    def print(self, str):
        self.debug_func()
        #print(str + "The counter reached " + str(self.debug))

debug_object=debug_func()

class RUDPClient:

    def __init__(self, debug=False):
        self.buff = 0
        self.debug = debug
        self.dropped = 0
        self.connected = False
        self.closed = False
        self.timer = None
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        debug_object.print("Error in sock")
        self.write_buffer = [None] * MAX_BYTES
        self.order = [None] * MAX_BYTES
        self.mutex = Lock()
        self.mutexr = Lock()
        self.read_buffer = b''
        self.send_seq = 0
        self.nxt_send_seq = 0
        self.recv_seq = 0

    def connect(self, address):
        self.listener = Listener(self)
        self.listener.start()
        self.peer_addr = address
        pckt = Packet()
        pckt.syn = 1
        self.write(pckt)
        cnt = 0
        while not self.connected:
            debug_object.print("Error in connection")
            cnt += 1
            time.sleep(POLL_INTERVAL)
            if cnt >= 150:
                raise Exception("Host unreachable!")

    def synack(self):
        if not self.connected:
            self.write_buffer[0] = None
            self.connected = True
            self.recv_seq += 1
            self.send_seq += 1

    def send_finack(self):
        self.connected = False
        self.send_seq = self.nxt_send_seq
        pckt = Packet()
        pckt.ack = 1
        pckt.fin = 1
        if self.debug:
            debug_object.print("dehub yahan")
            print(datetime.datetime.now().time())
            print("Packet sent:")
            print(pckt)
        self.sock.sendto(pckt.encode(), self.peer_addr)

    def read_data(self, pckt, source_addr):
        if self.debug:
            print(datetime.datetime.now().time())
            print("Packet received:")
            print(pckt)

        if source_addr != self.peer_addr:
            return


        if pckt.ack and pckt.syn:
            self.synack()
            debug_object.print("Debug here")
            return

        if pckt.ack and pckt.fin:
            self.finack()
            debug_object.print("Debug here")
            return


        if pckt.fin:
            self.send_finack()
            debug_object.print("Debug here")
            return

        if pckt.ack:
            count = pckt.ackno
            count = count - self.send_seq
            if count <= 0:
                return
            idx = self.send_seq % MAX_BYTES
            v = self.send_seq
            self.mutex.acquire()
            debug_object.print("Debug here")
            while v < pckt.ackno:
                if self.write_buffer[idx]:
                    self.buff -= len(self.write_buffer[idx].payload)
                self.write_buffer[idx] = None
                idx += 1
                v += 1
                if idx >= MAX_BYTES:
                    idx -= MAX_BYTES
            self.send_seq = v
            self.mutex.release()
        else:
            idx = pckt.seqno 
            idx= idx % MAX_BYTES
            if pckt.seqno >= self.recv_seq:
                if self.order[idx] == None:
                    self.order[idx] = pckt
                else:
                    self.dropped += 1
            debug_object.print("Debug here")
            if pckt.seqno == self.recv_seq:
                start = idx
                data = b''
                b = pckt.seqno
                while True:
                    if self.order[start] == None:
                        break
                    data += self.order[start].payload
                    self.order[start] = None
                    b += 1
                    start += 1
                    if start >= MAX_BYTES:
                        start -= MAX_BYTES
                self.mutexr.acquire()
                self.read_buffer += data
                self.mutexr.release()
                self.recv_seq = b
            debug_object.print("Debug here")
            pckt = Packet()
            pckt.ack = 1
            pckt.ackno = self.recv_seq
            # send ack
            self.sock.sendto(pckt.encode(), source_addr)

    def write(self, pckt):
        self.mutex.acquire()
        pckt.seqno = self.nxt_send_seq
        self.write_buffer[self.nxt_send_seq % MAX_BYTES] = pckt
        self.nxt_send_seq += 1
        self.mutex.release()
        if self.debug:
            debug_object.print("Debug here")
            print(datetime.datetime.now().time())
            print("Packet sent:")
            print(pckt)
        self.sock.sendto(pckt.encode(), self.peer_addr)
        if self.timer == None or not self.timer.running:
            debug_object.print("Debug here")
            self.timer = Timer(self.timeout, TIMEOUT)
            self.timer.start()

    def timeout(self):
        if self.send_seq == self.nxt_send_seq:
            return
        i = self.send_seq
        idx = i % MAX_BYTES
        b = self.nxt_send_seq
        cnt = 0
        while i < b:
            if self.write_buffer[idx] == None:
                debug_object.print("Debug here")
                i = i + 1
                idx = idx + 1
                if idx >= MAX_BYTES:
                    idx -= MAX_BYTES
                continue
            cnt = cnt + 1
            pckt = self.write_buffer[idx]
            if self.debug:
                print(datetime.datetime.now().time())
                print("Packet sent:")
                print(pckt)
                debug_object.print("Debug here")
            self.sock.sendto(pckt.encode(), self.peer_addr)
            if cnt >= RWND:
                break
            idx += 1
            i += 1
            if idx >= MAX_BYTES:
                idx = idx - MAX_BYTES
        # restart timer
        self.timer = Timer(self.timeout, TIMEOUT)
        self.timer.start()

    def recv(self, max_bytes):
        if self.closed:
            raise Exception("Socket closed")
        while True:
            if len(self.read_buffer) > 0:
                self.mutexr.acquire()
                l=0
                l = min(len(self.read_buffer), max_bytes)
                data = self.read_buffer[:l]
                self.read_buffer = self.read_buffer[l:]
                self.mutexr.release()
                return data
            if not self.connected:
                return None
            time.sleep(POLL_INTERVAL)
        debug_object.print("Debug here")

    def send(self, data):
        if self.closed:
            debug_object.print("Debug here")
            raise Exception("Socket closed")
        if not self.connected:
            debug_object.print("Debug here")
            raise Exception("Peer disconnected")
        while len(data) > 0:
            rem = min(len(data), MAX_PCKT_SIZE)
            payload = data[:rem]
            # wait till receiver has acked enough bytes
            while self.buff + rem > MAX_BYTES:
                time.sleep(POLL_INTERVAL)
            self.buff += rem
            pckt = Packet()
            data = data[rem:]
            pckt.payload = payload
            self.write(pckt)

    def finack(self):
        self.send_seq = self.nxt_send_seq
        if self.timer != None and self.timer.running:
            debug_object.print("")
            self.timer.finish()
        self.listener.finish()

    def close(self):
        self.closed = True
        if self.connected:
            self.connected = False
            while self.send_seq < self.nxt_send_seq:
                time.sleep(POLL_INTERVAL)
            pckt = Packet()
            pckt.fin = 1
            cnt = 0
            self.write(pckt)
            while self.send_seq < self.nxt_send_seq and cnt < 100:
                time.sleep(POLL_INTERVAL)
                cnt += 1
        self.finack()


class RUDPServer:

    def __init__(self, debug=False):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.binded = False
        self.listening = False
        self.closed = False
        self.debug = debug
        self.connections = {}
        self.new_connections = []

    def read_data(self, pckt, source_addr):
        if source_addr in self.connections:
            debug_object.print("")
            self.connections[source_addr].read_data(pckt, source_addr)
            return

        if pckt.syn:
            if not self.listening:
                return
            self.new_connection(source_addr)
            debug_object.print("")
            return

    def bind(self, address):
        self.sock.bind(address)
        debug_object.print("")
        self.binded = True

    def listen(self):
        if not self.binded:
            debug_object.print("")
            raise Exception("Socket not binded")
        self.listening = True
        self.listener = Listener(self)
        # Start listening
        self.listener.start()
        debug_object.print("")

    def new_connection(self, client_addr):
        self.connections[client_addr] = ClientHandler(self, client_addr, debug=self.debug)
        self.new_connections.append(client_addr)

    def accept(self):
        while True:
            if len(self.new_connections) > 0:
                addr = self.new_connections[0]
                self.new_connections = self.new_connections[1:]
                return self.connections[addr], addr
            time.sleep(POLL_INTERVAL)

    def close(self):
        self.closed = False
        self.listening = False
        # close all unaccepted connections
        for addr in self.new_connections:
            nc = self.connections[addr]
            nc.close()
            debug_object.print("")
        self.listener.finish()

    def close_connection(self, addr):
        del self.connections[addr]



class ClientHandler:

    def __init__(self, rudp, client_addr, debug):
        self.send_seq = 1
        self.nxt_send_seq = 1
        self.recv_seq = 1
        self.rudp = rudp
        self.sock = rudp.sock
        self.write_buffer = [None] * MAX_BYTES
        self.read_buffer = b''
        self.order = [None] * MAX_BYTES
        self.timer = None
        # mutex locks for write and read buffers
        self.debug = debug
        self.dropped = 0
        self.connected = True
        self.closed = False
        self.mutex = Lock()
        self.mutexr = Lock()
        self.peer_addr = client_addr
        # size of outbound packets
        self.buff = 0
        self.send_synack()

    def send_synack(self):
        pckt = Packet()
        pckt.syn = 1
        pckt.ack = 1
        if self.debug:
            debug_object.print("Error in synack")
            print(datetime.datetime.now().time())
            print("Packet sent:")
            print(pckt)
        self.sock.sendto(pckt.encode(), self.peer_addr)

    def send_finack(self):
        self.connected = False
        self.send_seq = self.nxt_send_seq
        pckt = Packet()
        pckt.fin = 1
        pckt.ack = 1
        if self.debug:
            debug_object.print("Error in finack")
            print(datetime.datetime.now().time())
            print("Packet sent:")
            print(pckt)
        self.sock.sendto(pckt.encode(), self.peer_addr)

    def read_data(self, pckt, source_addr):
        if self.debug:
            debug_object.print("Error in read_data")
            print(datetime.datetime.now().time())
            print("Packet received:")
            print(pckt)

        # Handle SYN
        if pckt.syn:
            self.send_synack()
            debug_object.print("")
            return

        # Handle FIN-ACK
        if pckt.fin and pckt.ack:
            self.finack()
            debug_object.print("")
            return

        # Handle FIN
        if pckt.fin:
            self.send_finack()
            return

        if pckt.ack:
            count = pckt.ackno 
            count = count - self.send_seq
            if count <= 0:
                return
            self.mutex.acquire()
            idx = self.send_seq 
            idx = idx % MAX_BYTES
            v = self.send_seq
            while v < pckt.ackno:
                if self.write_buffer[idx]:
                    self.buff = self.buff - len(self.write_buffer[idx].payload)
                self.write_buffer[idx] = None
                idx += 1
                v += 1
                if idx >= MAX_BYTES:
                    idx = idx - MAX_BYTES
            debug_object.print("")
            self.send_seq = v
            self.mutex.release()
        else:
            idx = pckt.seqno 
            idx = idx % MAX_BYTES
            if pckt.seqno >= self.recv_seq:
                if self.order[idx] == None:
                    self.order[idx] = pckt
                else:
                    self.dropped = self.dropped + 1
                # print(self.dropped)
            # if received expected packet update recv_seq no
            debug_object.print("")
            if pckt.seqno == self.recv_seq:
                data = b''
                b = pckt.seqno
                start = idx
                while True:
                    if self.order[start] == None:
                        break
                    data = data + self.order[start].payload
                    self.order[start] = None
                    b += 1
                    start += 1
                    if start >= MAX_BYTES:
                        start = start - MAX_BYTES
                debug_object.print("")
                self.mutexr.acquire()
                self.recv_seq = b
                self.read_buffer += data
                self.mutexr.release()
                debug_object.print("")
            pckt = Packet()
            pckt.ack = 1
            pckt.ackno = self.recv_seq
            # send ack
            self.sock.sendto(pckt.encode(), source_addr)
            debug_object.print("")

    def write(self, pckt):
        self.mutex.acquire()
        pckt.seqno = self.nxt_send_seq
        self.write_buffer[self.nxt_send_seq % MAX_BYTES] = pckt
        self.nxt_send_seq = self.nxt_send_seq + 1
        self.mutex.release()
        if self.debug:
            
            debug_object.print("Error in write data")
            print(datetime.datetime.now().time())
            print("Packet sent:")
            print(pckt)
        self.sock.sendto(pckt.encode(), self.peer_addr)
        # start timer if not running
        if self.timer == None or not self.timer.running:
            self.timer = Timer(self.timeout, TIMEOUT)
            self.timer.start()

    def timeout(self):
        cnt = 0
        if self.send_seq == self.nxt_send_seq:
            return
        i = self.send_seq
        b = self.nxt_send_seq
        idx = i
        idx= idx % MAX_BYTES
        while i < b:
            # packet already acked
            if self.write_buffer[idx] == None:
                i = i+1
                idx = idx+1
                if idx >= MAX_BYTES:
                    idx =idx- MAX_BYTES
                continue
            cnt = cnt + 1
            pckt = self.write_buffer[idx]
            if self.debug:
                print(datetime.datetime.now().time())
                print("Packet sent:")
                print(pckt)
                debug_object.print("debug here")
            self.sock.sendto(pckt.encode(), self.peer_addr)
            if cnt >= RWND:
                break
            i = i + 1
            idx = idx + 1
            if idx >= MAX_BYTES:
                idx = idx - MAX_BYTES
        # restart timer
        debug_object.print("")
        self.timer = Timer(self.timeout, TIMEOUT)
        self.timer.start()

    def recv(self, max_bytes):
        if self.closed:
            raise Exception("Socket closed")
        while True:
            if len(self.read_buffer) > 0:
                self.mutexr.acquire()
                l=0
                l = min(len(self.read_buffer), max_bytes)
                data = self.read_buffer[:l]
                self.read_buffer = self.read_buffer[l:]
                self.mutexr.release()
                return data
            if not self.connected:
                debug_object.print("Not connected")
                return None
            time.sleep(POLL_INTERVAL)

    def send(self, data):
        if self.closed:
            raise Exception("Socket closed")
        if not self.connected:
            raise Exception("Peer disconnected")
        while len(data) > 0:
            rem=0
            rem = min(len(data), MAX_PCKT_SIZE)
            payload = data[:rem]
            # wait till receiver has acked enough bytes
            while self.buff + rem > MAX_BYTES:
                time.sleep(POLL_INTERVAL)
            self.buff += rem
            data = data[rem:]
            pckt = Packet()
            pckt.payload = payload
            self.write(pckt)
    
    def close(self):
        self.closed = True
        if self.connected:
            self.connected = False
            # Wait till all data is sent
            while self.send_seq < self.nxt_send_seq:
                time.sleep(POLL_INTERVAL)
            # send FIN
            pckt = Packet()
            pckt.fin = 1
            self.write(pckt)
            # Wait for fin-ack atmost 100 * POLL_INTERVAL
            cnt = 0
            while self.send_seq < self.nxt_send_seq and cnt < 100:
                time.sleep(POLL_INTERVAL)
                cnt = cnt + 1
            debug_object.print("")
        self.finack()
        self.rudp.close_connection(self.peer_addr)


    def finack(self):
        self.send_seq = self.nxt_send_seq
        if self.timer != None and self.timer.running:
            self.timer.finish()

    
class Listener(threading.Thread):
    def __init__(self, rudp_sock):
        threading.Thread.__init__(self)
        self.rudp_sock = rudp_sock
        self.running = True

    def run(self):
        self.rudp_sock.sock.setblocking(False)
        # start listener
        while True:
            # Receive datagram
            try:
                msg, source_addr = self.rudp_sock.sock.recvfrom(MAX_BYTES)
                pckt = Packet(msg)
                self.rudp_sock.read_data(pckt, source_addr)
            except socket.error as e:
                time.sleep(POLL_INTERVAL)
            if self.running == False:
                return

    def finish(self):
        self.running = False


class Timer(threading.Thread):

    def __init__(self, callback, seconds):
        threading.Thread.__init__(self)
        self.callback = callback
        self.running = True
        self.seconds = seconds

    def timer_debug(self,list):
        time.sleep(3)
        list.append(True)


    def finish(self):
        self.running = False

    def run(self):
        time.sleep(self.seconds)
        if self.running:
            self.callback()
        self.running = False



class Packet:

    def __init__(self, data=None):
        self.seqno = 0
        self.ackno = 0
        self.syn = 0
        self.ack = 0
        self.fin = 0
        self.payload = b''
        if data:
            self.decode(data)

    def decode(self, data):
        flags = data[0]
        self.syn = int((flags & 4) > 0)
        self.ack = int((flags & 2) > 0)
        self.fin = int((flags & 1) > 0)
        self.seqno = int.from_bytes(data[1:5], 'big')
        self.ackno = int.from_bytes(data[5:9], 'big')
        self.payload = data[9:]

    def encode(self):
        # flag format SYN | ACK | FIN
        data = b''
        ack = self.ack
        ack <<= 1
        syn = self.syn
        syn <<= 2
        fin = self.fin
        flags = syn | ack | fin
        data += flags.to_bytes(1, 'big')
        data += self.seqno.to_bytes(4, 'big')
        data += self.ackno.to_bytes(4, 'big')
        data += self.payload
        return data

    def __str__(self):
        s = "-" * 30 + "\n" + \
            f"SYN: {self.syn}, ACK: {self.ack}, FIN: {self.fin}" + "\n" + \
            f"Seqno: {self.seqno}, Ackno: {self.ackno}" + "\n" + \
            "-" * 30 + "\n"
        return s




